# KotlinYouTube

This application makes use of PierfrancesoSoffritti's android-youtube-player library to play YouTube videos

The app currently plays one of seven videos form a predetermined playlist
